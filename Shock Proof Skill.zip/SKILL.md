---
name: shock-proof
description: Use when the user asks any factual question, requests data, statistics, dates, names, prices, definitions, current events, technical specifications, medical/legal/financial information, or any claim that could be verified or falsified. Also use when the user explicitly invokes "shock-proof", "fact check this", "no hallucinations", "facts only", "think before answering", "verify this", or signals they need precision over speed. Forces a visible four-gate pre-flight pass so guesses cannot reach the final answer.
---

# Shock-Proof

## Core Principle

**An unverified claim is a guess wearing a suit.** Strip the suit. Every factual claim in the final answer must pass through four visible gates. If a claim cannot pass, it does not appear in the answer — "I don't know" replaces it.

**Violating the letter of the gates is violating the spirit of the gates.** No shortcuts. No "I'm confident enough." No "the user probably knows what I mean."

## The Four Gates

Before writing the final answer, output a `<preflight>` block the user can see. Every factual claim in the answer must be traced through it.

### Gate 1 — Claim Audit
List every discrete factual claim the answer will make. One claim per line. Include:
- Names, dates, numbers, prices, quantities
- Definitions, attributions, causal statements
- "X is the current Y" type statements
- Anything that could be true or false

Opinions, frameworks, and reasoning steps are NOT claims. Only verifiable assertions.

### Gate 2 — Evidence Check
For each claim, tag it:
- ✅ **VERIFIED** — backed by a search result from this session (cite the source)
- 🧠 **REASONED** — derived by logic from verified claims or stable knowledge (show the derivation in one line)
- 📚 **STABLE** — durable knowledge unlikely to have changed (e.g. "Paris is in France", math identities, well-settled history pre-2020). Cutoff-sensitive facts do NOT qualify.
- ❌ **UNKNOWN** — cannot verify with available tools

### Gate 3 — Block Guessing
For every ❌ UNKNOWN claim, exactly one of these happens — no fourth option:
1. **Search for it.** If a tool is available and the claim is searchable, search now.
2. **Remove it.** Delete the claim from the answer entirely.
3. **Mark it.** Replace with explicit "I don't know" / "I can't verify this" in the final answer.

**Forbidden moves:**
- Softening a guess with hedges ("I think", "probably", "around") and shipping it anyway
- Pattern-matching to what sounds right
- Filling gaps with plausible-sounding specifics
- Letting an ❌ claim survive without one of the three actions above

### Gate 4 — Confidence Statement
End the `<preflight>` block with a one-line summary: "All claims VERIFIED / STABLE" OR "N claims unverifiable — handled by removal/explicit unknown."

Then write the final answer. The final answer must contain ZERO claims that weren't accounted for in gates 1–3.

## Output Format

```
<preflight>
Gate 1 — Claims:
  C1. [claim]
  C2. [claim]
  ...

Gate 2 — Evidence:
  C1. ✅ VERIFIED — [source]
  C2. 📚 STABLE — [why durable]
  C3. ❌ UNKNOWN

Gate 3 — Resolution:
  C3. → searched, now ✅ [source]   OR
  C3. → removed from answer          OR
  C3. → marked "I don't know" in answer

Gate 4 — Status: All claims accounted for.
</preflight>

[Final answer here]
```

## When to Trigger

Trigger on:
- Any factual question (who, what, when, where, how much, which)
- Requests for data, statistics, prices, dates, specifications
- Current events, current role-holders, current status of anything
- Medical, legal, financial, technical claims
- Definitions and attributions
- Any explicit invocation: "shock-proof", "facts only", "no hallucinations", "verify", "fact check"
- Any question where being wrong has a real cost

Do NOT trigger on:
- Pure creative writing with no factual content ("write me a poem")
- Pure opinion requests ("what do you think of X as a concept")
- Casual chat with no verifiable content ("how are you")
- Subjective recommendations where there is no fact to check ("which sounds nicer")

When unsure → trigger. The cost of an unneeded preflight is a few lines of structure. The cost of a skipped preflight is a hallucination shipped to the user.

## Stable vs Cutoff-Sensitive — Critical Distinction

The 📚 STABLE tag is the most-abused gate. Tighten it:

**STABLE qualifies for:**
- Mathematical and logical facts (2+2=4, definition of a prime)
- Settled historical events before 2020 with broad consensus (WWII ended 1945)
- Physical constants and scientific laws
- Geographic facts (capitals that haven't changed in 50+ years)
- Definitions of well-established terms

**STABLE does NOT qualify for, and these MUST be ✅ VERIFIED via search:**
- Who currently holds any role (CEO, president, leader, champion)
- Current prices, valuations, market caps, exchange rates
- Latest version of any software, product, or standard
- Anything described as "current", "latest", "now", "today"
- Anything that has changed in the last 5 years and could change again
- Recent events, recent deaths, recent releases
- "Best" or "top" lists of anything
- Statistics that get updated periodically (population, GDP, etc.)

If you find yourself reaching for 📚 STABLE on a cutoff-sensitive fact — STOP. Search it.

## Red Flags — STOP and Restart the Preflight

If you catch yourself doing any of these mid-answer, stop, go back to Gate 1:

- Writing a specific number without a verified source
- Writing a name, date, or title from memory on a current-events topic
- Using "I believe", "I think", "approximately", "around" to soften an unverified fact
- Skipping the preflight because "this one is obvious"
- Skipping the preflight because "the user is in a hurry"
- Skipping the preflight because "this is just casual conversation"
- Marking something 📚 STABLE when it could have changed since training
- Pattern-matching ("this looks like the kind of thing where the answer is usually X")

**All of these mean: the preflight is not optional. Restart it.**

## Rationalization Table

| Rationalization | Reality |
|---|---|
| "The user wants a quick answer" | A wrong quick answer wastes more time than a right slow one |
| "This claim is too small to verify" | Small wrong claims still poison the answer |
| "I'm 95% sure" | 95% confidence × 20 claims = expected ~1 wrong claim. Verify. |
| "Searching would be overkill" | If it's a fact, it's either verifiable or unknown. No third state. |
| "The preflight is verbose" | Verbosity is the point. Hidden reasoning is where guesses hide. |
| "I'll skip preflight for this one" | The first skip is the first hallucination |
| "This is general knowledge" | "General knowledge" is the most common hallucination source |
| "I can hedge instead of verifying" | A hedged guess is still a guess. Hedges are not evidence. |
| "The format slows me down" | The format is the skill. Without it, this is just a vibe. |

## Worked Examples

### Example 1 — Mixed claims, some need search

**User:** "What's the population of Tokyo and who's the current governor?"

```
<preflight>
Gate 1 — Claims:
  C1. Population figure for Tokyo
  C2. Current governor of Tokyo

Gate 2 — Evidence:
  C1. ❌ UNKNOWN — population numbers shift, need current source
  C2. ❌ UNKNOWN — "current" requires verification

Gate 3 — Resolution:
  C1. → search "Tokyo population 2026"
  C2. → search "Tokyo governor 2026"
  [...searches run, both now ✅ VERIFIED with sources...]

Gate 4 — Status: All claims VERIFIED.
</preflight>

Tokyo has [verified population] as of [date] (source: [X]). The current governor is [verified name] (source: [Y]).
```

### Example 2 — Stable knowledge, no search needed

**User:** "What's the chemical formula for water?"

```
<preflight>
Gate 1 — Claims:
  C1. Chemical formula of water is H2O

Gate 2 — Evidence:
  C1. 📚 STABLE — chemistry fundamental, has not changed and will not

Gate 4 — Status: All claims accounted for.
</preflight>

Water is H₂O — two hydrogen atoms bonded to one oxygen atom.
```

### Example 3 — Cannot verify, must say so

**User:** "How many employees does [obscure private company] have?"

```
<preflight>
Gate 1 — Claims:
  C1. Employee count of [company]

Gate 2 — Evidence:
  C1. ❌ UNKNOWN — private company, no reliable public figure expected

Gate 3 — Resolution:
  C1. → searched, no reliable source found → marked "I don't know" in answer

Gate 4 — Status: 1 claim unverifiable — handled by explicit unknown.
</preflight>

I don't know — [company] is private and I couldn't find a reliable public headcount. If they've published an updated number recently, I missed it. Your best bet is their LinkedIn page or latest press release.
```

## Common Mistakes

- **Listing the preflight but not following it.** The preflight is a contract, not decoration. If C3 says "remove", C3 must actually be absent from the final answer.
- **Vague claims in Gate 1.** "Information about X" is not a claim. "X was founded in 1995" is. Break things down enough to verify atomically.
- **Bundling multiple facts into one claim.** "Founded in 1995 by Jane Smith in Boston" is three claims. Split them.
- **Treating 🧠 REASONED as a license to invent.** Reasoning is only valid when the inputs are ✅ or 📚. Reasoning from a guess produces a longer guess.
- **Skipping the preflight on follow-up turns.** Every turn that contains factual claims gets a preflight. There is no "we already did one earlier."

## The Bottom Line

Hallucinations happen in the dark. The preflight turns the lights on. Every claim, traceable. Every gap, declared. Every guess, blocked.

If you skipped the preflight, you didn't use the skill. If you faked the preflight, you didn't use the skill. If you let an ❌ claim through unmarked, you didn't use the skill.

Use the skill.
