---
name: prompt-forge
description: Use when the user wants to write a new prompt from scratch, improve an existing prompt, audit a prompt that isn't working, rewrite a vague or weak prompt, learn prompting patterns, or asks "how do I prompt for X". Also use when the user pastes a prompt and asks for feedback, says their AI output is bad/wrong/generic, mentions "prompt engineering", "better prompt", "fix my prompt", "prompt template", "prompt for ChatGPT/Claude/Midjourney/DALL-E", or signals frustration with AI output quality. Covers text prompts (chat, coding, writing) and image prompts. Forces the seven-element RCCFERH checklist on every build and rewrite.
---

# Prompt Forge

## Core Principle

**A weak prompt is a wish. A strong prompt is a specification.** The job of this skill is to turn wishes into specifications — and to teach the patterns as it goes, so the user gets stronger over time, not more dependent.

**Every prompt this skill produces must pass the seven-element checklist (RCCFERH).** Missing elements are not "stylistic choices" — they are defects. Skipping the checklist because "the prompt is simple" is the most common failure mode and is forbidden.

## The Seven Elements — RCCFERH

Every strong prompt has these. Missing any one is a defect to be named and fixed.

| # | Element | Question it answers | Example |
|---|---------|---------------------|---------|
| **R** | **Role** | Who is the AI being? | "You are a senior copy editor with 15 years at The Atlantic." |
| **C** | **Context** | What background does it need? | "I'm writing for an audience of solo founders, 30-45, mostly technical." |
| **C** | **Constraints** | What's in/out of bounds? Length? Tone? | "≤300 words. Conversational but not casual. No emojis. No em dashes." |
| **F** | **Format** | What exact output shape? | "Return as: H2 headline + 3 bullet points + 1-sentence CTA." |
| **E** | **Examples** | What does success look like? | "Like this: [paste 1-2 examples]. Not like this: [counter-example]." |
| **R** | **Reasoning trigger** | When should it think before answering? | "First list assumptions, then reason step-by-step, then write the answer." |
| **H** | **Handling unknowns** | What to do when uncertain? | "If you don't know, say 'I don't know' — do not guess or fill gaps." |

**Memory hook:** *Real Cooks Care For Every Recipe's Honor.*

Not every element needs heavy weight in every prompt — a haiku request doesn't need 200 words of context — but every element must be *consciously addressed*. "Not needed here" is a valid answer if justified; silent omission is not.

## Mode Detection

The skill operates in one of four modes. Detect from the user's input:

| User input shape | Mode | Output |
|------------------|------|--------|
| Pastes a prompt | **AUDIT + REWRITE** | Score the prompt → show rewrite → explain diffs |
| Describes a goal but no draft | **BUILD** | Ask 3-5 targeted questions → construct prompt |
| Asks "why does this work" / "what's the pattern" | **TEACH** | Explain the pattern, then offer to apply it |
| Mix (e.g. "here's my prompt, why is it bad and fix it") | **AUDIT + REWRITE + TEACH** | Run audit, rewrite, teach the lessons |

When ambiguous, ask one clarifying question. Do not guess the mode.

## BUILD Mode — From Goal to Prompt

When the user describes what they want but hasn't drafted a prompt:

**Step 1 — Detect the target model class** (affects which patterns apply):
- **Chat/reasoning models** (Claude, GPT, Gemini) — full RCCFERH applies
- **Image models** (Midjourney, DALL-E, SDXL, Flux) — use the IMAGE checklist below instead
- **Code-focused use** (Cursor, Copilot, Claude Code) — emphasis on Context, Constraints, Examples

**Step 2 — Ask only the questions you can't infer.** Maximum 5 questions. Common ones:
- What's the goal in one sentence?
- Who's the audience / reader?
- What format do you need the output in?
- Do you have an example of "good" you can share?
- What's the failure mode you've seen so far?

Do NOT ask things you can reasonably infer from context. Asking too many questions is itself a defect.

**Step 3 — Build the prompt, explicitly tagged.** Use this skeleton:

```
# ROLE
[1-3 sentences establishing identity, seniority, perspective]

# CONTEXT
[Background the model needs that it wouldn't have by default]

# TASK
[Single-sentence statement of what to produce]

# CONSTRAINTS
- [Length / word count]
- [Tone / register]
- [What's forbidden]
- [What's required]

# OUTPUT FORMAT
[Exact structure — markdown, sections, JSON schema, etc.]

# EXAMPLES
## Good:
[1-2 examples of desired output]
## Avoid:
[1 counter-example if relevant]

# REASONING
[Optional: "First think about X, then..."]

# IF UNCERTAIN
[What to do when the model doesn't know]
```

**Step 4 — Show your work.** After the prompt, in a short block, name which RCCFERH elements you used and why you weighted them as you did. This is the teach-by-doing layer.

## AUDIT Mode — Score and Diagnose

Given an existing prompt, produce this audit block:

```
<audit>
Score: X/10

RCCFERH coverage:
  R Role ......... [✅ / ⚠️ weak / ❌ missing] — [one-line reason]
  C Context ...... [✅ / ⚠️ / ❌] — [reason]
  C Constraints .. [✅ / ⚠️ / ❌] — [reason]
  F Format ....... [✅ / ⚠️ / ❌] — [reason]
  E Examples ..... [✅ / ⚠️ / ❌] — [reason]
  R Reasoning .... [✅ / ⚠️ / ❌] — [reason]
  H Handle ?? .... [✅ / ⚠️ / ❌] — [reason]

Top 3 defects:
  1. [defect] — [why it hurts output]
  2. ...
  3. ...

Likely failure modes:
  - [what the model will probably do wrong with this prompt]
</audit>
```

**Scoring rubric:**
- 10 = production-ready, all 7 elements strong
- 7-9 = solid, 1-2 elements weak
- 4-6 = workable but will produce mediocre output
- 1-3 = vague wish, will produce generic slop
- 0 = not actually a prompt

Be honest. A polite 7/10 on a 4/10 prompt is dishonesty, and it doesn't help the user improve.

## REWRITE Mode — Strengthen the Prompt

After AUDIT, always offer the rewrite. Format:

```
<rewrite>
[The improved prompt, complete and copy-pasteable]
</rewrite>

<diff>
Changes I made and why:
  1. Added ROLE — [original had none; without it the model defaults to generic assistant voice]
  2. Tightened CONSTRAINTS — [original said "short", which can mean anything from 50 to 500 words]
  3. ...
</diff>
```

The diff section is non-negotiable — this is where the teaching happens. Every change must be justified in terms of *what failure it prevents*.

## TEACH Mode — Explain the Pattern

When the user asks "why" or wants to understand:

- Name the pattern (e.g. "few-shot prompting", "role priming", "format anchoring", "negative examples")
- One-line definition
- Why it works (what model behavior it exploits)
- One concrete before/after example
- When NOT to use it

Keep teaching tight. The user is here to write better prompts, not read a textbook.

## IMAGE Prompt Variant

For image models (Midjourney, DALL-E, SDXL, Flux, Stable Diffusion), RCCFERH is replaced by **SCALES**:

| # | Element | Example |
|---|---------|---------|
| **S** | **Subject** | "A weathered fisherman, mid-60s, salt-and-pepper beard" |
| **C** | **Composition** | "Medium shot, rule of thirds, subject left of center" |
| **A** | **Atmosphere** | "Golden hour, soft fog, melancholy mood" |
| **L** | **Lighting** | "Rim lighting from behind, warm key from camera-right" |
| **E** | **Era/Style** | "Shot on Kodak Portra 400, 1970s editorial style, grain visible" |
| **S** | **Specifications** | "--ar 3:2 --style raw --v 6" (or model-specific params) |

Same discipline: every element addressed consciously. Image prompts fail when they specify subject without composition, or style without lighting.

## Common Defects and Fixes

| Defect | Symptom in output | Fix |
|---|---|---|
| No role | Generic assistant voice, hedging, over-explanation | Add 1-sentence identity |
| Vague constraints ("short", "professional") | Output drifts wildly across runs | Quantify: word count, specific tone markers |
| No format | Output structure changes every time | Specify exact shape, ideally with template |
| No examples | Output matches the *form* but misses the *flavor* | Add 1-2 few-shot examples |
| No failure handling | Model invents facts to fill gaps | Add "If unsure, say so" instruction |
| Wall of prose | Model misses requirements buried in paragraphs | Use sections, headers, bullets |
| Negative-only ("don't do X") | Model fixates on the forbidden thing | Pair every "don't" with a "do" |
| Asking model to "be creative" | Bland output | Specify *what kind* of creative (genre, reference, constraint) |
| Multiple tasks in one prompt | Model does one well, others poorly | Split into separate prompts or sequence explicitly |
| Politeness padding ("please", "thanks") | Slightly longer outputs, no quality gain | Remove — models don't need manners, they need clarity |

## Red Flags — Restart the Build

If you catch yourself doing any of these, stop and restart:

- Producing a prompt without naming all seven elements
- Scoring an audit at 8+ when 2+ elements are ⚠️ or ❌
- Skipping the diff explanation on a rewrite
- Telling the user "this prompt is good enough" when it scored under 7
- Adding fluff to a prompt to make it look more thorough (length ≠ quality)
- Treating "be creative" or "make it engaging" as valid constraints
- Forgetting to ask about output format
- Asking more than 5 build questions

## Rationalization Table

| Rationalization | Reality |
|---|---|
| "The prompt is simple, doesn't need the full checklist" | Simple prompts fail in the same predictable ways. Run the checklist. |
| "The user is in a hurry, skip the audit" | A bad prompt rewritten poorly wastes more time than a slow good one |
| "Examples are overkill for this" | Examples are the single highest-leverage element. Default to including them. |
| "I'll just rewrite without explaining" | Then the user learns nothing and comes back tomorrow with the same prompt |
| "8/10 sounds nice" | Honest scores teach; flattering scores don't |
| "Adding role priming feels performative" | It changes output quality measurably. Performative ≠ ineffective. |
| "The user knows what they meant by 'professional'" | The model doesn't. Quantify. |
| "Negative instructions are clear enough" | Pair every don't with a do. Always. |

## Worked Examples

### Example 1 — AUDIT + REWRITE

**User pastes:** "Write me a blog post about productivity for entrepreneurs. Make it good and not too long."

```
<audit>
Score: 3/10

RCCFERH coverage:
  R Role ......... ❌ missing — no identity given, will produce generic blog voice
  C Context ...... ❌ missing — no audience specifics, no publication, no goal
  C Constraints .. ⚠️ weak — "not too long" is unmeasurable; "good" is not a constraint
  F Format ....... ❌ missing — no structure specified (intro? subheads? CTA?)
  E Examples ..... ❌ missing — no reference for tone or style
  R Reasoning .... ❌ missing — no thinking instruction
  H Handle ?? .... ❌ missing — no fallback for gaps

Top 3 defects:
  1. "Good" and "not too long" are wishes, not specs — output will be generic and inconsistent length
  2. "Productivity for entrepreneurs" is the most over-written topic on the internet — without a fresh angle, output will be slop
  3. No format = unpredictable structure, hard to use or edit

Likely failure modes:
  - Listicle of clichés ("wake up early", "time-block", "delegate")
  - Generic "thought leader" voice, indistinguishable from any other AI blog
  - Length anywhere from 400 to 2000 words depending on the run
</audit>

<rewrite>
You are a senior editor at a publication like First Round Review — known for specific, contrarian, story-driven pieces for operators.

I'm writing a blog post for solo founders (1-10 employees, bootstrapped, technical background, ages 28-45). They've read every productivity post on the internet and are tired of the standard advice.

# TASK
Write a 600-800 word post on one counterintuitive productivity insight specific to solo founders — something a salaried PM wouldn't relate to.

# CONSTRAINTS
- 600-800 words
- One core insight, not a listicle
- Open with a specific scene or moment, not a thesis statement
- No bullet points in the first 200 words
- Conversational but precise — write like Paul Graham, not LinkedIn
- No clichés: avoid "hustle", "grind", "10x", "ship fast", "move fast and break things"

# OUTPUT FORMAT
- Headline (≤8 words, specific not clever)
- Opening scene (1-2 paragraphs)
- The insight, stated plainly
- Why it's counterintuitive (1-2 paragraphs)
- One concrete example with names and numbers if possible
- One-sentence close that lands

# EXAMPLES
Good tone reference: First Round Review, "The Hard Thing About Hard Things" blog era Ben Horowitz
Avoid: Medium "5 habits of highly effective" posts, LinkedIn thought-leader voice

# IF UNCERTAIN
If you don't have a strong counterintuitive insight, stop and tell me — don't pad with generic advice.
</rewrite>

<diff>
Changes I made and why:
  1. Added ROLE (First Round editor) — anchors the model to a specific publication voice instead of generic "blog assistant"
  2. Added AUDIENCE specifics (solo founders, bootstrapped, technical, 28-45) — model now knows what references will land and what won't
  3. Quantified length (600-800 vs "not too long") — eliminates the most common drift
  4. Constrained STRUCTURE (one insight, not listicle) — listicles are the default failure mode for this topic
  5. Added NEGATIVE examples (clichés to avoid) paired with POSITIVE direction (PG-style) — pairing matters; "don't" alone doesn't redirect
  6. Specified OUTPUT FORMAT (headline + scene + insight...) — model now produces consistent shape across runs
  7. Added HANDLING ("if you don't have a strong insight, stop") — pairs with shock-proof; prevents padding with generic advice
</diff>
```

### Example 2 — BUILD from scratch

**User says:** "I want a prompt that helps me reply to negative customer reviews."

Ask 3 questions max:
1. What industry/product? (changes tone register)
2. What outcome — defuse, retain, or just acknowledge? (changes reply structure)
3. Do you have 1-2 examples of replies you've sent that worked? (anchors the voice)

Then build the prompt with all seven elements explicit. Skipped here for brevity, but the structure is identical to Example 1's `<rewrite>` block.

### Example 3 — TEACH

**User asks:** "Why do examples matter so much?"

```
Pattern: Few-shot prompting

Definition: Showing the model 1-3 examples of input→output pairs before asking for the real output.

Why it works: Language models are pattern matchers. A description of what you want activates one set of patterns; a concrete example activates a much narrower, more specific set. "Write a witty tweet" → broad. "Write a tweet like these: [3 examples]" → narrow.

Before: "Write a product description for my candle in a friendly tone."
After:  "Write a product description for my candle. Match this voice:
        Example 1: [paste]
        Example 2: [paste]"

When NOT to use: Pure factual lookup (no style to anchor), or when you actively want variance (brainstorming).
```

## Common Mistakes

- **Producing a prompt without the seven sections visible.** Even if the elements are present "in spirit," the user can't learn from a wall of prose. Use the labeled skeleton.
- **Skipping the diff on rewrites.** The diff is where the user learns. Without it, this is a ghostwriting service, not a teaching skill.
- **Inflating audit scores to be nice.** 4/10 means 4/10. Honest feedback is the gift.
- **Asking 8 build questions when 3 would do.** Friction kills the workflow. Infer what you can.
- **Using "be creative" / "make it engaging" / "high quality" in a rewrite.** These are the exact phrases this skill exists to eliminate. Catch yourself.

## Pairs Well With

- **shock-proof** — when the prompt is for factual output, add a shock-proof gate to the HANDLE-UNKNOWNS section.
- The two skills compose: prompt-forge writes a clear spec; shock-proof prevents hallucination inside that spec.

## The Bottom Line

A prompt is a contract between the user and the model. Vague contracts produce vague outputs. The seven elements are the contract terms. The audit names the missing terms. The rewrite fills them in. The diff teaches the user why each term matters.

If you produced a prompt without the seven elements named, you didn't use the skill. If you rewrote without explaining what you changed and why, you didn't use the skill. If you scored a 4/10 prompt as 7/10 to be polite, you didn't use the skill.

Use the skill.
